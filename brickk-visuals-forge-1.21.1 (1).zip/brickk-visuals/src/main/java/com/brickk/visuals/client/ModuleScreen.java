package com.brickk.visuals.client;

import com.brickk.visuals.module.Module;
import com.brickk.visuals.module.Modules;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ModuleScreen extends Screen {

    public ModuleScreen() {
        super(Component.literal("Brickk Visuals"));
    }

    @Override
    protected void init() {
        int buttonWidth = 150;
        int buttonHeight = 20;
        int gap = 4;
        int x = this.width / 2 - buttonWidth / 2;
        int y = this.height / 2 - (Modules.ALL.size() * (buttonHeight + gap)) / 2 + 10;

        for (Module module : Modules.ALL) {
            this.addRenderableWidget(
                    Button.builder(label(module), button -> {
                        module.toggle();
                        button.setMessage(label(module));
                    }).bounds(x, y, buttonWidth, buttonHeight).build()
            );
            y += buttonHeight + gap;
        }
    }

    private static Component label(Module module) {
        return Component.literal(module.getName() + ": " + (module.isEnabled() ? "ON" : "OFF"))
                .withStyle(module.isEnabled() ? ChatFormatting.GREEN : ChatFormatting.RED);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFF);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (VisualsClient.MENU_KEY.matches(keyCode, scanCode)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
