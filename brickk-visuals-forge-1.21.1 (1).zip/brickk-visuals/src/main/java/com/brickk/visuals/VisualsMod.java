package com.brickk.visuals;

import net.minecraftforge.fml.common.Mod;

@Mod(VisualsMod.MODID)
public class VisualsMod {
    public static final String MODID = "visuals";

    public VisualsMod() {
    }
}
