package com.brickk.visuals.module;

import java.util.List;

public final class Modules {
    public static final Module COORDINATES = new Module("Coordinates", true);
    public static final Module FPS = new Module("FPS", true);
    public static final Module MODULE_LIST = new Module("Module List", true);
    public static final Module HIT_MARKER = new Module("Hit Marker", true);
    public static final Module HIT_PARTICLES = new Module("Hit Particles", true);
    public static final Module BLOCK_PARTICLES = new Module("Block Particles", true);

    public static final List<Module> ALL = List.of(
            COORDINATES, FPS, MODULE_LIST, HIT_MARKER, HIT_PARTICLES, BLOCK_PARTICLES
    );

    private Modules() {
    }
}
