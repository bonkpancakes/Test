package com.brickk.visuals.client;

import com.brickk.visuals.VisualsMod;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = VisualsMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class VisualsClient {
    public static final KeyMapping MENU_KEY = new KeyMapping(
            "key.visuals.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.visuals");

    private VisualsClient() {
    }

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(MENU_KEY);
    }
}
