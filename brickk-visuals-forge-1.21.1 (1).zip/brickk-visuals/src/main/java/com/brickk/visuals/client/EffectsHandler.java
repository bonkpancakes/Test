package com.brickk.visuals.client;

import com.brickk.visuals.VisualsMod;
import com.brickk.visuals.module.Module;
import com.brickk.visuals.module.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = VisualsMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class EffectsHandler {

    public static final int HIT_TICKS = 10;
    public static int hitTicks = 0;

    private EffectsHandler() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        if (hitTicks > 0) {
            hitTicks--;
        }
        for (Module module : Modules.ALL) {
            module.tickAnim();
        }

        Minecraft mc = Minecraft.getInstance();
        while (VisualsClient.MENU_KEY.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                mc.setScreen(new ModuleScreen());
            }
        }
    }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide() || player != Minecraft.getInstance().player) {
            return;
        }
        if (Modules.HIT_MARKER.isEnabled()) {
            hitTicks = HIT_TICKS;
        }
        if (Modules.HIT_PARTICLES.isEnabled()) {
            spawnHitParticles(event.getTarget());
        }
    }

    private static void spawnHitParticles(Entity target) {
        Level level = target.level();
        RandomSource rand = level.getRandom();

        for (int i = 0; i < 16; i++) {
            level.addParticle(ParticleTypes.CRIT,
                    target.getRandomX(0.5D), target.getY(0.5D), target.getRandomZ(0.5D),
                    (rand.nextDouble() - 0.5D) * 0.7D,
                    rand.nextDouble() * 0.5D,
                    (rand.nextDouble() - 0.5D) * 0.7D);
        }
        for (int i = 0; i < 6; i++) {
            level.addParticle(ParticleTypes.ENCHANTED_HIT,
                    target.getRandomX(0.5D), target.getY(0.6D), target.getRandomZ(0.5D),
                    (rand.nextDouble() - 0.5D) * 0.4D,
                    rand.nextDouble() * 0.3D,
                    (rand.nextDouble() - 0.5D) * 0.4D);
        }
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        Level level = event.getLevel();
        if (!level.isClientSide() || !Modules.BLOCK_PARTICLES.isEnabled()) {
            return;
        }
        if (event.getEntity() != Minecraft.getInstance().player) {
            return;
        }

        RandomSource rand = level.getRandom();
        if (rand.nextInt(3) != 0) {
            return;
        }

        BlockPos pos = event.getPos();
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) {
            return;
        }

        Direction face = event.getFace() != null ? event.getFace() : Direction.UP;
        for (int i = 0; i < 4; i++) {
            double x = pos.getX() + 0.5D + face.getStepX() * 0.55D
                    + (face.getAxis() == Direction.Axis.X ? 0.0D : (rand.nextDouble() - 0.5D) * 0.9D);
            double y = pos.getY() + 0.5D + face.getStepY() * 0.55D
                    + (face.getAxis() == Direction.Axis.Y ? 0.0D : (rand.nextDouble() - 0.5D) * 0.9D);
            double z = pos.getZ() + 0.5D + face.getStepZ() * 0.55D
                    + (face.getAxis() == Direction.Axis.Z ? 0.0D : (rand.nextDouble() - 0.5D) * 0.9D);

            level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, state), x, y, z,
                    face.getStepX() * 0.1D + (rand.nextDouble() - 0.5D) * 0.1D,
                    face.getStepY() * 0.1D + rand.nextDouble() * 0.1D,
                    face.getStepZ() * 0.1D + (rand.nextDouble() - 0.5D) * 0.1D);
        }
        level.addParticle(ParticleTypes.END_ROD,
                pos.getX() + 0.5D + face.getStepX() * 0.55D,
                pos.getY() + 0.5D + face.getStepY() * 0.55D,
                pos.getZ() + 0.5D + face.getStepZ() * 0.55D,
                0.0D, 0.02D, 0.0D);
    }
}
