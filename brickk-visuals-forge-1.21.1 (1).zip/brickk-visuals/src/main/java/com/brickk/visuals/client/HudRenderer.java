package com.brickk.visuals.client;

import com.brickk.visuals.VisualsMod;
import com.brickk.visuals.module.Module;
import com.brickk.visuals.module.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Mod.EventBusSubscriber(modid = VisualsMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class HudRenderer {

    private static final int PANEL = 0x90000000;
    private static final int LINE_HEIGHT = 11;

    private HudRenderer() {
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }

        GuiGraphics graphics = event.getGuiGraphics();
        Font font = mc.font;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        renderInfo(graphics, font, mc);
        if (Modules.MODULE_LIST.isEnabled()) {
            renderModuleList(graphics, font, sw);
        }
        if (Modules.HIT_MARKER.isEnabled()) {
            renderHitMarker(graphics, sw, sh);
        }
    }

    private static int rainbow(long offset) {
        float hue = ((System.currentTimeMillis() / 15L + offset) % 360L) / 360.0F;
        return 0xFF000000 | Mth.hsvToRgb(hue, 0.55F, 1.0F);
    }

    private static void renderInfo(GuiGraphics graphics, Font font, Minecraft mc) {
        LocalPlayer player = mc.player;
        List<String> lines = new ArrayList<>();

        if (Modules.COORDINATES.isEnabled()) {
            lines.add(String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f",
                    player.getX(), player.getY(), player.getZ()));
            lines.add(String.format(Locale.ROOT, "Facing: %s (%.0f)",
                    player.getDirection().getName(), Mth.wrapDegrees(player.getYRot())));
        }
        if (Modules.FPS.isEnabled()) {
            lines.add("FPS: " + mc.getFps());
        }
        if (lines.isEmpty()) {
            return;
        }

        int width = 0;
        for (String line : lines) {
            width = Math.max(width, font.width(line));
        }

        int x = 4;
        int y = 4;
        int bottom = y + lines.size() * LINE_HEIGHT - 1;
        graphics.fill(x - 2, y - 2, x + width + 3, bottom, PANEL);
        graphics.fill(x - 2, y - 2, x - 1, bottom, rainbow(0L));

        for (String line : lines) {
            graphics.drawString(font, line, x + 1, y, 0xFFFFFFFF, true);
            y += LINE_HEIGHT;
        }
    }

    private static void renderModuleList(GuiGraphics graphics, Font font, int sw) {
        List<Module> visible = new ArrayList<>();
        for (Module module : Modules.ALL) {
            if (module != Modules.MODULE_LIST && module.getAnim() > 0.02F) {
                visible.add(module);
            }
        }
        visible.sort(Comparator.comparingInt((Module m) -> font.width(m.getName())).reversed());

        int y = 4;
        int index = 0;
        for (Module module : visible) {
            String name = module.getName();
            int textWidth = font.width(name);

            float a = module.getAnim();
            float eased = 1.0F - (1.0F - a) * (1.0F - a);
            int offset = (int) ((textWidth + 10) * (1.0F - eased));
            int x = sw - textWidth - 6 + offset;
            int color = rainbow(index * 18L);

            graphics.fill(x - 3, y - 1, sw + offset, y + 10, PANEL);
            graphics.fill(sw - 2 + offset, y - 1, sw + offset, y + 10, color);
            graphics.drawString(font, name, x, y, color, true);

            y += Math.round(LINE_HEIGHT * eased);
            index++;
        }
    }

    private static void renderHitMarker(GuiGraphics graphics, int sw, int sh) {
        if (EffectsHandler.hitTicks <= 0) {
            return;
        }
        float t = EffectsHandler.hitTicks / (float) EffectsHandler.HIT_TICKS;
        int alpha = Mth.clamp((int) (255 * t), 0, 255);
        int color = (alpha << 24) | 0xFFFFFF;

        int cx = sw / 2;
        int cy = sh / 2;
        int gap = 3 + (int) ((1.0F - t) * 4.0F);

        for (int i = gap; i < gap + 4; i++) {
            graphics.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, color);
            graphics.fill(cx - i - 1, cy + i, cx - i, cy + i + 1, color);
            graphics.fill(cx + i, cy - i - 1, cx + i + 1, cy - i, color);
            graphics.fill(cx - i - 1, cy - i - 1, cx - i, cy - i, color);
        }
    }
}
