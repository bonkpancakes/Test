package com.brickk.visuals.module;

public class Module {
    private final String name;
    private boolean enabled;
    private float anim; // 0..1, slide-in animation for the module list

    public Module(String name, boolean enabled) {
        this.name = name;
        this.enabled = enabled;
        this.anim = enabled ? 1.0F : 0.0F;
    }

    public String getName() {
        return name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        enabled = !enabled;
    }

    public float getAnim() {
        return anim;
    }

    public void tickAnim() {
        float target = enabled ? 1.0F : 0.0F;
        anim += (target - anim) * 0.25F;
        if (Math.abs(target - anim) < 0.005F) {
            anim = target;
        }
    }
}
